const assert=require('node:assert/strict'),screen=require('./dist/build-screen.js');
const o={slots:254,existing:0,startsPerMonth:10,capitalPerNode:5e6,permitMonths:6,civilMonths:9,equipmentMonths:18,installMonths:6,eligibleCapitalShare:.15,eligibleCostReduction:.2,printPremiumPerNode:1e5,civilPrintableShare:.5,civilTimeReduction:.5,approved:true};
const r=screen(o);assert.equal(r.baselineProjectMonths,24);assert.equal(r.printingProjectMonths,24);assert.equal(r.monthsSaved,0);assert.equal(r.baselineLastMonths,49.3);assert.equal(r.requiredConcurrentProjects,240);
const fast=screen({...o,equipmentMonths:10});assert.equal(fast.baselineProjectMonths,21);assert.equal(fast.printingProjectMonths,18.75);assert.equal(fast.monthsSaved,2.25);
const no=screen({...o,approved:false});assert.equal(no.hypotheticalGrossSaving,0);assert.equal(no.printingPremium,0);assert.equal(no.hypotheticalCapitalAfterPrinting,no.baselineCapital);
assert.equal(r.baselineCapital-r.hypotheticalCapitalAfterPrinting,254*50000);
assert.equal(screen({...o,existing:254}).printingLastMonths,0);assert.throws(()=>screen({...o,existing:255}));assert.throws(()=>screen({...o,startsPerMonth:0}));assert.throws(()=>screen({...o,civilTimeReduction:1.1}));
console.log('PASS: equipment bottleneck, civil critical path, regional cadence, qualification gate, cost shares and invalid inputs.');
