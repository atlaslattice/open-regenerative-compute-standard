from pathlib import Path
import json, re

root = Path(__file__).resolve().parent
dist = root / 'dist'
pool = {p.name: p.read_text() for p in dist.iterdir() if p.suffix in {'.json', '.md', '.html'}}
encoded = json.dumps(pool, ensure_ascii=True).replace('<', '\\u003c')
shim = r'''
(function(){
const files=__DATA__;
const nativeFetch=window.fetch.bind(window);
window.fetch=function(input,options){const raw=typeof input==='string'?input:input.url;
 if(!/^(https?:|data:|blob:)/i.test(raw)){const key=raw.replace(/^\.\//,'').split('?')[0];if(Object.hasOwn(files,key)){const type=key.endsWith('.json')?'application/json':'text/plain';return Promise.resolve(new Response(files[key],{status:200,headers:{'Content-Type':type}}))}}
 return nativeFetch(input,options);
};
document.addEventListener('click',function(event){const a=event.target.closest?.('a');if(!a)return;const href=a.getAttribute('href');if(!href||/^(https?:|data:|blob:|#)/i.test(href))return;const key=href.replace(/^\.\//,'').split('?')[0];if(!Object.hasOwn(files,key))return;event.preventDefault();const b=document.createElement('a'),type=key.endsWith('.json')?'application/json':key.endsWith('.html')?'text/html':'text/markdown';b.href=URL.createObjectURL(new Blob([files[key]],{type}));b.download=key;b.click();setTimeout(()=>URL.revokeObjectURL(b.href),5000);
});
})();
'''.replace('__DATA__', encoded)
html = (dist / 'index.html').read_text()
html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', lambda m: '<style data-source="'+m[1]+'">' + (dist / m[1]).read_text() + '</style>', html)
html = html.replace('<script src="leaflet.js">', '<script>' + shim + '</script><script src="leaflet.js">')
def inline(m):
    source = (dist / m[1]).read_text()
    source = re.sub(r'//# sourceMappingURL=.*', '', source)
    return '<script data-source="'+m[1]+'">' + source.replace('</script', '<\\/script') + '</script>'
html = re.sub(r'<script src="([^"]+)"></script>', inline, html)
output = root / 'ORCS_American_Resilience_Lab_v08.html'
output.write_text(html)
print(f'{output}: {output.stat().st_size:,} bytes')
