# ORCS America Supply Atlas v0.6

Private research dashboard built from the recovered ORCS National Supply Dashboard v0.1 and the user-described DragonSeek monitoring direction. Earlier interface preserved at dist/legacy-v01.html. The recovered DragonSeek Portable 1.7.1 source was inspected as a reference; its original 43-metric registry was not found. This project's 43-metric catalog is provisional.

## Implemented

- Responsive state/county choropleth with self-hosted Leaflet and bundled boundaries.
- Census July 1 2023 population estimates (2023 vintage): 51 state/DC records, 3,144 county-equivalent records. Older Plotly geometry uses a different vintage; unmatched geographies remain missing.
- National 2025 trade cards and metrics using the February 19 2026 BEA/Census release. Historical release values, not latest-revised or current-year estimates.
- Bundled NWS alerts, USGS global M2.5+ past-day events, and NOAA SWPC Kp snapshots, with retrieval receipts. User-triggered browser refresh adapters handle fetch failures explicitly. No automatic updates while the page is closed.
- Single-commodity/unit/year resource ledger with strict CSV validation, missing-value handling, duplicate rejection, optional device persistence and filtered export.
- Annual resource balance, gross import share, reserve days, reserve gap and domestic production-to-demand coverage.
- Single-route domestic substitution screening, constrained by uncommitted origin output, source reserve top-up, replaceable destination international imports and user route capacity. Transport loss and user prices drive delivered replacement and buyer savings. Domestic supplier receipts and gross foreign-spend displacement are not additive net benefits.
- Explicit synthetic example loaded only on user request; JSON brief and route exports.
- Provenance and integration status for all 43 definitions, including unconnected satellite/air/marine and environmental layers.

## Limitations

This is not a production-ready government decision system. Most supply datasets are not yet integrated. No nationwide commodity network, automated optimization, trade forecast, satellite propagation or flight tracking is implemented. No seismic predictions or hazard-to-loss estimates. No multi-route shared-capacity bookkeeping. The Census API rejected unauthenticated access; downloadable Population Estimates were substituted and labels updated.

No browser-control skill is available in this environment, so visual browser QA was skipped under the Sites workflow. JavaScript syntax, accounting logic, CSV rejection paths, route constraints and bundled JSON/source consistency were checked locally.

Sources and timestamps are in the interface and dist/population-provenance.json and dist/snapshot-receipts.json. Upstream DragonSeek reference: atlaslattice/manus-artifacts, pinned source revision e22e2190d14144b1f12c14ad6bcaf66d4f184345, research/dragonseek_1_6_1.

The static site has no server, API secrets or build dependency. Serve dist/ as the root.

## v0.3 Desalination and brine recovery

Added 67 source-linked facilities, a separate U.S./Qingdao facility map, an incremental ZLD/mineral inventory and cost screen, 25/50/75% extraction sensitivity, explicit unknown-chemistry handling, and downloadable scenario/register/research-note files. References and limitations are in dist/brine-research.md. The 67 records are not a full national inventory. Model costs and extraction fractions are user assumptions, not a vendor quote or verified Dongjiakou performance. No automatic import displacement is credited. Prior interface and source history are retained.

## v0.4 Wastewater and isotope accounts

Added 34,665 EPA facility-permit records and 5,333 ocean-name/Hawaii outfall records, with exact query provenance and reconciled pagination counts. Separate records are not unique plants or additive flow accounts. National nutrient/contaminant chemistry joins are incomplete. Added bounded struvite, additional ammonium, sludge-route, residual-capture, reuse and deuterium inventory/economic screens. The example is synthetic and all isotope value defaults to zero or unpriced. See dist/wastewater-research.md for equations, references and scope.

## v0.5 Selection and data access
Resource and metric native selectors appear directly above the map, including on mobile. Changing a resource switches context metrics to production; missing observations are explicitly labeled. Sources & coverage links a versioned data catalog and the 43 metric definitions. JSON datasets and CSV/JSON scenario exports remain distinct from a server API, which is not implemented.

## v0.6 Wastewater opportunity ranking
Added flow-quality review flags, separate discovery and assessed-stream rankings, strict incremental-stream assessment imports, buyer caps, baseline avoidance and cost accounting, operator recovery benchmarks, JSON Schema and portable ranking exports. Permit flows are never converted to nutrient yields without explicit chemistry. Browser QA unavailable; pure-function and binding checks used.
