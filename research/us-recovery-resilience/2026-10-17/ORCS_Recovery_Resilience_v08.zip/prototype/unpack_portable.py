"""Reconstruct editable dist/ from the portable dashboard, without network access."""
from html.parser import HTMLParser
from pathlib import Path
import json,re

root=Path(__file__).resolve().parent
html=(root/'ORCS_American_Resilience_Lab_v08.html').read_text()
match=re.search(r'const files=(.*?);\nconst nativeFetch=',html,re.S)
if not match:raise SystemExit('Bundled source pool not found')
out=root/'dist';out.mkdir(exist_ok=True)
for name,text in json.loads(match[1]).items():
    if Path(name).name!=name:raise SystemExit('Unexpected bundled path')
    (out/name).write_text(text)
class Assets(HTMLParser):
    def __init__(self):super().__init__();self.name=None;self.text=[]
    def handle_starttag(self,tag,attrs):
        if tag in ['script','style'] and 'data-source' in dict(attrs):
            self.name=dict(attrs)['data-source'];self.text=[]
    def handle_data(self,data):
        if self.name:self.text.append(data)
    def handle_endtag(self,tag):
        if tag in ['script','style'] and self.name:
            if Path(self.name).name!=self.name:raise ValueError('Unexpected asset path')
            (out/self.name).write_text(''.join(self.text).replace('<\\/script','</script'))
            self.name=None;self.text=[]
Assets().feed(html)
print('Reconstructed',out)
