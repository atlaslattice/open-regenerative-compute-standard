US WASTEWATER RESOURCES, ENERGY AND RESILIENCE - RESEARCH v0.3
Analysis date: October 16, 2026 (America/Chicago)

Open US_Wastewater_Resources_Energy_Resilience_v03.pdf for the complete report.

Reproduce results with Python 3, no extra packages or network:
  python run_model.py
Run numerical/accounting regression checks:
  python test_model.py

inputs.json contains assumptions, source metadata and the earlier nutrient model.
results.json contains separate 25/50/75 scenarios, energy alternatives, cost stress
cases, context-only resource inventories, unpriced gaps and accounting limits.
sources.json is the 39-source evidence register; report.md is searchable report text.

The 25/50/75 nutrient cases are net qualified-recovery assumptions. Energy cases
are deployment shares of dated literature potentials. They are not measured
2026 fleet outputs or verified bankable projects. Cost bands and product yield
assumptions are editable stress tests, not vendor quotes. Existing reuse must be
subtracted before calling any quantity additional supply. Actual import
replacement is unknown pending buyer, grade, route and baseline matching.

Never add full AD-CHP, AD-RNG and HTL yields for the same sludge. Null means
unestablished, not zero. No water sales, speculative isotope sales, contaminant
destruction or soil-use clearance is credited. Separate national material
accounts cannot be collapsed into a combined profit by summing gross values.
